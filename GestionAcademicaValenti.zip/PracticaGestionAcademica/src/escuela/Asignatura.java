package escuela;
/* CLASE ASIGNATURA.
 * EN ESTE CASO CREAMOS UNA CLASE CON TRES ATRIBUTOS, NOMBRE DE LA ASIGTURA , EL CODIGO Y UNA LISTA DE ALUMNOS 
 * QUE CURSAN DICHA ASIGNATURA.
 * 
 */
import java.util.ArrayList;
import java.util.List;

public final class Asignatura {
    private String nombre;
    private String codigo;
    private List<Alumno> alumnos;
    
    //METODO CONSTRUCTOR
    public Asignatura(String nombre, String codigo) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.alumnos = new ArrayList<>();
    }

    //GETTERS
    public String getNombre() {
        return nombre;
    }
    public String getCodigo() {
        return codigo;
    }
    public List<Alumno> getAlumnos() {
        return alumnos;
    }
    
    //CREAMOS ESTE METODO PARA PODER INTRODUCIR LA LISTA DE ALUMNOS DENTRO DE UNA ASIGNTURA.
    //COMO ES UNA ARRAYLIST AÑADIMOS CON EL METODO ADD.
    public void agregarAlumno(Alumno alumno) {
        alumnos.add(alumno);
    }
}

