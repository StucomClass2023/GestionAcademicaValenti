package escuela;
/*Gestión académica

Crear un programa para guardar datos referentes a alumnos y asignaturas de una escuela.
Respecto a los alumnos, interesa saber el nombre y el dni.
En cuanto a las asignaturas, interesa saber cuantas se han creado, el nombre, el código y que alumnos las cursan.
Por otro lado, también es necesario definir los métodos siguientes:

• Un método que permita añadir un alumno a una asignatura.
• Un método que permita listar los alumnos de una asignatura.

Además, habrá que definir una clase que se utilizará para hacer el mantenimiento de la información sobre las 
asignaturas y los alumnos que hay en la escuela. Para esto se crea la clase Departamento, que contiene la lista de
 alumnos de la escuela y la lista de asignaturas que se imparten y las mantiene.
Finalmente, se necesita una clase que gestione la entrada/salida de datos, que presente el menú de opciones al
 usuario y llame a las clases pertinentes. Para esta función, se define la clase Secretaria.
*/

import java.util.List;
import java.util.Scanner;

public class Secretaria {
	
	// SE DECLARAN LAS VARIABLES QUE SE VAN A USAR EN LA CLASE SECRETARIA.
	private Departamento departamento;
	private Scanner scanner;
	
	
	//METODO MAIN.
	public static void main(String[] args) {
        //SE CREA UNA NUEVA SECRETARIA Y SE MUESTRA EL MENU DE OPCIONES
		Secretaria secretaria = new Secretaria();
		secretaria.mostrarMenu();
    }
				//CONSTRUCTOR DE SECRETARIA , EN EL QUE TAMBIEN LLAMAMOS AL METODO INICIALIZARDATOS().
				public Secretaria() {
			        departamento = new Departamento();
			        scanner = new Scanner(System.in);
			        inicializarDatos();
			    }
			
			    private void inicializarDatos() {
			        // CREAMOS 10 ALUMNOS
			        departamento.agregarAlumno(new Alumno("Juan Marti", "11.111.111-G"));
			        departamento.agregarAlumno(new Alumno("Marta Luengo", "22.222.222-T"));
			        departamento.agregarAlumno(new Alumno("Pere Batet", "33.333.333-M"));
			        departamento.agregarAlumno(new Alumno("Ana Garcia", "44.444.444-Y"));
			        departamento.agregarAlumno(new Alumno("Luisa Torres", "55.555.555-G"));
			        departamento.agregarAlumno(new Alumno("Laura Souto", "66.666.667-D"));
			        departamento.agregarAlumno(new Alumno("Carlos Martinez", "77.888.888-K"));
			        departamento.agregarAlumno(new Alumno("Andreia Sanchez", "99.111.222-X"));
			        departamento.agregarAlumno(new Alumno("Javier Fernandez", "66.555.789-S"));
			        departamento.agregarAlumno(new Alumno("Elena Gomez", "12.234.567-L"));
			
			        // CREAMOS 5 ASIGNATURAS
			        departamento.agregarAsignatura(new Asignatura("MATEMATICAS", "MAT01"));
			        departamento.agregarAsignatura(new Asignatura("INGLES", "ING01"));
			        departamento.agregarAsignatura(new Asignatura("HISTORIA", "HIST01"));
			        departamento.agregarAsignatura(new Asignatura("NATURALES", "NAT01"));
			        departamento.agregarAsignatura(new Asignatura("PROGRAMACION", "PRO01"));
			        
			        // ASIGNAMOS 4 ALUMNOS A ASIGNATURAS
			        departamento.agregarAlumnoToAsignatura(departamento.getAlumnoPorDNI("11.111.111-G"), departamento.getAsignaturaPorCodigo("ING01"));
			        departamento.agregarAlumnoToAsignatura(departamento.getAlumnoPorDNI("22.222.222-T"), departamento.getAsignaturaPorCodigo("MAT01"));
			        departamento.agregarAlumnoToAsignatura(departamento.getAlumnoPorDNI("33.333.333-M"), departamento.getAsignaturaPorCodigo("HIST01"));
			        departamento.agregarAlumnoToAsignatura(departamento.getAlumnoPorDNI("44.444.444-Y"), departamento.getAsignaturaPorCodigo("NAT01"));
			    }

			    // CREAMOS EL MENU Y USAMOS SECUENCIAS DE ESCAPE ANSI DE LA CONSOLA, PARA DAR COLOR.
			    public void mostrarMenu() {
			        int opcion;
			        do {
			        	System.out.println("\u001B[m============== MENU ===============");
			        	System.out.println("\u001B[36m1. Agregar alumno");
			        	System.out.println("2. \u001B[36mLista Actual de Alumnos");
			        	System.out.println("3. \u001B[36mAgregar asignatura");
			        	System.out.println("4. \u001B[36mLista Actual de Asignaturas");
			        	System.out.println("5. \u001B[36mAgregar alumno a asignatura");
			        	System.out.println("6. \u001B[36mListar alumnos por asignatura");
			        	System.out.println("\u001B[31m7. Salir");
			        	System.out.print("\u001B[0mEscoge una opcion: ");
			        	opcion = scanner.nextInt();
			        	
			            switch (opcion) {  case 1: agregarAlumno();  break;
			            				   case 2: listarAlumnos(); break;
			            				   case 3: agregarAsignatura(); break;
			            				   case 4: listarAsignaturas(); break;
			            				   case 5: agregarAlumnoAsignatura(); break;
			            				   case 6: listarAlumnosPorAsignatura(); break;
			            				   case 7: System.out.println("\n"+"\n"+"\n"+"\n"+"\n"+"\n"+"\n"+"Cierre de Aplicacion! "); break;
			            				   default:System.out.println("Valor invalido. El valor debe ser de 1 a 7."); break;
			            				}
			        	} while (opcion != 7);
			    }
			    
			    //METODO PARA AGREGAR UN ALUMNO DENTRO DEL ARRAY DE ALUMNOS.SE PIDE NOMBRE Y DNI
			    private void agregarAlumno() {
			        scanner.nextLine(); // Limpiar el buffer del scanner
			        System.out.print("Teclea nombre y apellido del nuevo alumno(Iniciales Mayusculas): ");
			        String nombre = scanner.nextLine();
			        System.out.print("Tecla su DNI (formato 00.000.000-X): ");
			        String dni = scanner.nextLine();
			        
			        Alumno existenteAlumno = buscarAlumnoPorDNI(dni);
			        if (existenteAlumno != null) {
			        	System.out.println("ERROR, DNI YA REGISTRADO!!");
			        	return;
			        }
			        //llamamos al metodo dentro de departamente donde realizamos un add
			        Alumno alumno = new Alumno(nombre, dni);
			        departamento.agregarAlumno(alumno);
			        System.out.println("\n" + " DONE! .  Nuevo alumno agregado correctamente.");
			        System.out.println();
			    }
			
			    //METODO PARA LISTAR LOS ALUMNOS, EN ORDEN ALFABETICO.
			    private void listarAlumnos() {
			        List<Alumno> listaAlumnos = departamento.getListaAlumnos();
			        System.out.println("Lista de Alumnos:");
			        for (Alumno alumno : listaAlumnos) {
			            System.out.println("Nombre: " + alumno.getNombre() + ", DNI: " + alumno.getDNI());
			        }
			        System.out.println();
			    }
			
			    //METODO PARA ASIGNAR ASIGNATURA A UN ALUMNO.
			    private void agregarAsignatura() {
			        scanner.nextLine(); // Limpiar el buffer del scanner
			        System.out.print("TECLEA EL NOMBRE DE LA ASIGNATURA: ");
			        String nombre = scanner.nextLine();
			        System.out.print("TECLEA EL CODIGO ASIGNATURA(TRES PRIMERAS LETRAS + 01): ");
			        String codigo = scanner.nextLine();
			        Asignatura asignatura = new Asignatura(nombre, codigo);
			        departamento.agregarAsignatura(asignatura);
			        System.out.println("ASIGNATURA AÑADIDA CORRECTAMENTE.");
			        System.out.println();
			    }
			
			    private void listarAsignaturas() {
			        List<Asignatura> listaAsignaturas = departamento.getListaAsignaturas();
			        System.out.println("Lista de Asignaturas:");
			        for (Asignatura asignatura : listaAsignaturas) {
			            System.out.println("ASIGNATURA: " + asignatura.getNombre() + ", Codigoo: " + asignatura.getCodigo());
			        }
			        System.out.println();
			    }
			
			    private void agregarAlumnoAsignatura() {
			        scanner.nextLine(); // Limpiar el buffer del scanner
			        System.out.print("TECLEA EL CODIGO DE LA ASIGNATURA: ");
			        String codigoAsignatura = scanner.nextLine();
			        Asignatura asignatura = buscarAsignaturaPorCodigo(codigoAsignatura);
			        if (asignatura == null) {
			            System.out.println("\n" + "NO SE ENCONTRO EL CODIGO");
			            System.out.println();
			            return;
			        }
			
			        System.out.print("TECLEA EL DNI DEL ALUMNO: ");
			        String dniAlumno = scanner.nextLine();
			        Alumno alumno = buscarAlumnoPorDNI(dniAlumno);
			        if (alumno == null) {
			            System.out.println("\n" + "NO SE ENCONTRO NINGUN ALUMNO CON ESE DNI");
			            System.out.println();
			            return;
			        }
			
			        departamento.agregarAlumnoTOAsignatura(alumno, asignatura);
			        System.out.println("\n" + "ALUMNO AÑADIDO CORRECTAMENTE.");
			        System.out.println();
			    }
			
			    private void listarAlumnosPorAsignatura() {
			        scanner.nextLine(); // Limpiar el buffer del scanner
			        System.out.print("Ingrese el código de la asignatura: ");
			        String codigoAsignatura = scanner.nextLine();
			        Asignatura asignatura = buscarAsignaturaPorCodigo(codigoAsignatura);
			        if (asignatura == null) {
			            System.out.println("No se encontró la asignatura con el código proporcionado.");
			            System.out.println();
			            return;
			        }
			
			        List<Alumno> alumnosPorAsignatura = departamento.obtenerAlumnosPorAsignatura(asignatura);
			        System.out.println("Alumnos inscritos en la asignatura:");
			        for (Alumno alumno : alumnosPorAsignatura) {
			            System.out.println("Nombre: " + alumno.getNombre() + ", DNI: " + alumno.getDNI());
			        }
			        System.out.println();
			    }
			
			    private Asignatura buscarAsignaturaPorCodigo(String codigo) {
			        List<Asignatura> listaAsignaturas = departamento.getListaAsignaturas();
			        for (Asignatura asignatura : listaAsignaturas) {
			            if (asignatura.getCodigo().equals(codigo)) {
			                return asignatura;
			            }
			        }
			        return null;
			    }
			
			    private Alumno buscarAlumnoPorDNI(String dni) {
			        List<Alumno> listaAlumnos = departamento.getListaAlumnos();
			        for (Alumno alumno : listaAlumnos) {
			            if (alumno.getDNI().equals(dni)) {
			                return alumno;
			            }
			        }
			        return null;
			    }
}