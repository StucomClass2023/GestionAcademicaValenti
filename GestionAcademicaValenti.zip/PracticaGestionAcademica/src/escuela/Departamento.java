package escuela;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;


class Departamento {
    private List<Alumno> listaAlumnos;
    private List<Asignatura> listaAsignaturas;

    // TODOS LOS METODOS DE LA CLASE DEPARTAMENTO.
    
    //GENERAMOS UN ARRAQUE NUEVO DE LISTAALUMNOS Y ASIGNATURAS EN FORMA DE ARRAYLIST.
    public Departamento() {
        listaAlumnos = new ArrayList<>();
        listaAsignaturas = new ArrayList<>();
    }
    //EN LA CLASE DEPARTAMENTO TENEMOS TODOS LOS METODOS DEL PROGRAMA CON UN VALOR DE RETORNO.
    //EN AGREGARALUMNO, YA QUE LISTAALUMNOS SE TRATA DE UNA ARRAYLIST, APLICAMOS UN ADD PARA 
    //AÑADIR A NUESTRA LISTA UN NUEVO ALUMNO.TAMBIEN VAMOS A HACER QUE APAREZCAN ORDENADA CON 
    //EL METODO SORT.
    public void agregarAlumno(Alumno alumno) {
        listaAlumnos.add(alumno);
    }

    public List<Alumno> getListaAlumnos() {
    	ArrayList<Alumno> listaOrdenada = new ArrayList<>(listaAlumnos); // Crea una copia de la lista original
    	Collections.sort(listaOrdenada); // Ordena la lista copiada
    	return listaOrdenada;
    }

    public void agregarAsignatura(Asignatura asignatura) {
        listaAsignaturas.add(asignatura);
    }

    public List<Asignatura> getListaAsignaturas() {
        return listaAsignaturas;
    }

    public void agregarAlumnoTOAsignatura(Alumno alumno, Asignatura asignatura) {
        asignatura.agregarAlumno(alumno);
    }

    public List<Alumno> obtenerAlumnosPorAsignatura(Asignatura asignatura) {
        return asignatura.getAlumnos();
    }

	public Alumno getAlumnoPorDNI(String dni) {
	    for (Alumno alumno : listaAlumnos) {
	        if (alumno.getDNI().equals(dni)) {
	            return alumno;
	        }
	    }
	    return null;
	}
	
	public Asignatura getAsignaturaPorCodigo(String codigo) {
	    for (Asignatura asignatura : listaAsignaturas) {
	        if (asignatura.getCodigo().equals(codigo)) {
	            return asignatura;
	        }
	    }
	    return null;
	}
	
	public void agregarAlumnoToAsignatura(Alumno alumnoPorDNI, Asignatura asignaturaPorCodigo) {
		 asignaturaPorCodigo.agregarAlumno(alumnoPorDNI);
	}
}