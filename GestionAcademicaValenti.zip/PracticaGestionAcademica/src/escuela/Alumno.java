package escuela;
/*
 *  CLASE ALUMNO:
 *  Para poder usar el metodo sort, debemos implementar la interfaz Comparable
	en la clase alumno. Se trata de usar public class Alumno implements Comparable<Alumno>
	y crear el siguiente metodo: 
	public int compareTo(Alumno otroAlumno) {
	       return this.nombre.compareTo(otroAlumno.nombre);
	}
 */
// DECIMOS QUE LA CLASE ALUMNO ES FINAL PQ NO VAMOS A MODIFICAR LOS ALUMNOS UNA VEZ CREADOS.
public final class Alumno implements Comparable<Alumno> {
    
		private String nombre;
		private String dni;
		
			//CONSTRUCTOR DE LA CLASE ALUMNO
		    public Alumno(String nombre, String dni) {
		        this.nombre = nombre;
		        this.dni = dni;
		    }
		
		    //GETTERS DE LA CLASE ALUMNO,NO HACEN FALTA LOS GETTERS PQ NO VAMOS A MODIFICAR 
		    // LOS VALORES DE ALUMNO. 
			public String getNombre() {
		        return nombre;
		    }
		    public String getDNI() {
		        return dni;
		    }
		    
		    //Metodo comparteTO para usar el COLLECTIONS.SORT.
		    public int compareTo(Alumno otroAlumno) {
		        return this.nombre.compareTo(otroAlumno.nombre);
		    }
}